import random

class Classe:

    quantidadeAssentos = 72 ##
    assentosPorColuna = 6  ##
    numFileiras = int(quantidadeAssentos/assentosPorColuna)

    def __init__(self,nome):
        self.nomeClasse = nome
        self.assentos = []
        self.assentosDisponiveis = []
        self.lotada = False

    def ocuparAssento(self,passageiro,numero = None):

        if self.assentosDisponiveis == []:
            self.lotada = True
            return

        if numero == None:
            numero = random.choice(self.assentosDisponiveis)

        for assento in self.assentos:
            if assento.numero == numero:
                assento.ocuparAssento(passageiro)

        self.assentosDisponiveis.remove(numero)
