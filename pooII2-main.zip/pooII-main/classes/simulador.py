import random
import time
import os
import sqlite3
import matplotlib.pyplot as plt
from classes.pessoa import *
from classes.classe import *
from classes.aviao import *

class Simulador:

    def pegarSimulacoesTestadas(self):
        
        if 'simulacoes.db' not in os.listdir():
            con = sqlite3.connect("simulacoes.db")
            cursor = con.cursor()
            cursor.execute('''
                CREATE TABLE simulacoes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    simulacao TEXT,
                    tempo INTEGER
                )
            ''')
            con.commit()
            con.close()

        print('-----------TABELA---------------')
        con = sqlite3.connect("simulacoes.db")
        cursor = con.cursor()
        cursor.execute('SELECT * FROM simulacoes')
        resultados = cursor.fetchall()
        simulacoes = []
        melhorSequencia = None
        melhorTempo = None
        for resultado in resultados:
            if melhorTempo == None:
                melhorTempo = resultado[2]
                melhorSequencia = resultado[1]
            
            elif resultado[2] < melhorTempo:
                melhorTempo = resultado[2]
                melhorSequencia = resultado[1]

            simulacoes.append(resultado[1])
        con.close()

        matrixSimulacoes = []
        for i in simulacoes:
            sim = []
            for cada in i.split('_'):
                if cada != '':
                    sim.append(cada)
            matrixSimulacoes.append(sim)

        return {'matrix':matrixSimulacoes,'melhorTempo':melhorTempo,'melhorSequencia':melhorSequencia}


    def gerarGraficoTaxaDeVariacao(self):

        x = []  
        y = []

        con = sqlite3.connect("simulacoes.db")
        cursor = con.cursor()
        cursor.execute('SELECT * FROM simulacoes ORDER BY tempo DESC')
        resultados = cursor.fetchall()
        melhorTempo = None

        ultima = None

        for i,resultado in enumerate(resultados):

            if i % 100 == 0: 
                # melhor tempo atual deve ser diferente do ultimo tempo registrado nas quantidades de simulações e ser diferente de none
                if melhorTempo != ultima or ultima==None:
                    x.append(i)
                    y.append(melhorTempo)
                    ultima = melhorTempo

            if melhorTempo == None:
                melhorTempo = resultado[2]
            
            elif resultado[2] < melhorTempo:
                melhorTempo = resultado[2]
            
        con.close()

        plt.plot(x, y, color='black', linestyle='solid', linewidth=1)
        plt.title('Gráfico de Tempo de Embarque')
        plt.xlabel('Quantidade de Simulações')
        plt.ylabel('Tempo')
        plt.savefig('graficoTaxaDeVariacao.png')
        plt.show()

    def gerarGrafico(self):

        x = []
        y = []

        con = sqlite3.connect("simulacoes.db")
        cursor = con.cursor()
        cursor.execute('SELECT * FROM simulacoes')
        resultados = cursor.fetchall()
        melhorTempo = None

        ultima = None

        for i,resultado in enumerate(resultados):

            if i % 100 == 0: 
                # melhor tempo atual deve ser diferente do ultimo tempo registrado nas quantidades de simulações e ser diferente de none
                if melhorTempo != ultima or ultima==None:
                    x.append(i)
                    y.append(melhorTempo)
                    ultima = melhorTempo

            if melhorTempo == None:
                melhorTempo = resultado[2]
            
            elif resultado[2] < melhorTempo:
                melhorTempo = resultado[2]
            
        con.close()

        plt.plot(x, y, color='black', linestyle='solid', linewidth=1)
        plt.title('Gráfico de Tempo de Embarque')
        plt.xlabel('Quantidade de Simulações')
        plt.ylabel('Tempo')
        plt.savefig('grafico.png')
        plt.show()


    def rodarSimulacoes(self,quantidadeSimulacoes, opcao, qtdAssento, qtdColuna):
        sequencias = self.pegarSimulacoesTestadas()
        sequenciasTestadas = sequencias['matrix']
        #print('sequencia testadas:',sequenciasTestadas)
        #print('quantidadeDeTestadas:',len(sequenciasTestadas))
        melhorSequencia = sequencias['melhorSequencia']
        melhorTempo = sequencias['melhorTempo']
        
        con = sqlite3.connect("simulacoes.db")
        cursor = con.cursor()
        
        sequenciasTestes = []
        Classe.quantidadeAssentos = qtdAssento
        Classe.qtdColuna = qtdColuna

        for index,i in enumerate(range(quantidadeSimulacoes)):

            aviao = Aviao() ##
            tempo = 0
            contadorEntrada = 0

            filaDeEmbarque = []
            sequencia = []
            
            while True:
                
                filaDeEmbarque = []
                sequencia = []
                posicoes = []
                for i in aviao.coluna:
                    for numero in range(1,Classe.numFileiras+1):
                        posicoes.append(f'{i}{numero}')
                
                while posicoes != []:

                    posicao = random.choice(posicoes)
                    filaDeEmbarque.append(random.choice([Adulto('nome',posicao), Crianca('nome',posicao)]))
                    sequencia.append(posicao)
                    posicoes.remove(posicao)
                    
                if filaDeEmbarque not in sequenciasTestadas:
                    sequenciasTestadas.append(filaDeEmbarque)
                    break

            for _ in aviao.classes:

                while filaDeEmbarque != [] or not aviao.corredorVazio():

                    aviao.andarFila()
                    
                    ordem = ''
                    if(contadorEntrada < 10):
                        ordem = '0' + str(contadorEntrada)
                    else:
                        ordem = str(contadorEntrada)
                    
                    if filaDeEmbarque != []:
                        passageiro = filaDeEmbarque[0]
                        passageiro.ordemEntrada = ordem

                        if aviao.colocarfila(passageiro):
                            filaDeEmbarque.pop(0)    
                            contadorEntrada += 1    
                    
                    tempo += 1
                    
                    if opcao:
                        time.sleep(0.1)
                        os.system('clear')
                        print(f'simulação: {index + 1} de {quantidadeSimulacoes}')
                        print('melhor tempo:',melhorTempo)
                        print('faltando embarcar:',len(filaDeEmbarque))
                        print('tempo:',tempo)
                        print(aviao)

            if melhorTempo == None or tempo < melhorTempo:
                melhorTempo = tempo
                melhorSequencia = sequencia

            sequenciasTestadas.append(sequencia)
            
            stringSequencia = ''
            for cada in sequencia:
                stringSequencia += cada + '_'
            
            cursor.execute('INSERT INTO simulacoes (simulacao, tempo) VALUES (?, ?)', (stringSequencia,tempo))
                
        print('melhor sequencia:',melhorSequencia)
        print('melhorTempo:',melhorTempo)

        con.commit()
        con.close()

        self.gerarGrafico()
        self.gerarGraficoTaxaDeVariacao()