from classes.simulador import *



Simulador().rodarSimulacoes(10000, True)