from classes.simulador import *

Simulador().rodarSimulacoes(10000, False, 72, 6)