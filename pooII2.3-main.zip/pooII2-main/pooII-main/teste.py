from classes.simulador import *

Simulador().rodarSimulacoes(1, True, 72, 6)